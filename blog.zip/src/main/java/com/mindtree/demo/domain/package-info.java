/**
 * JPA domain objects.
 */
package com.mindtree.demo.domain;
