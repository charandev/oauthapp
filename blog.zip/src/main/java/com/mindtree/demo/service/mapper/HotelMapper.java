package com.mindtree.demo.service.mapper;

import com.mindtree.demo.domain.*;
import com.mindtree.demo.service.dto.HotelDTO;

import org.mapstruct.*;
import java.util.List;

/**
 * Mapper for the entity Hotel and its DTO HotelDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface HotelMapper {

    HotelDTO hotelToHotelDTO(Hotel hotel);

    List<HotelDTO> hotelsToHotelDTOs(List<Hotel> hotels);

    Hotel hotelDTOToHotel(HotelDTO hotelDTO);

    List<Hotel> hotelDTOsToHotels(List<HotelDTO> hotelDTOs);
}
