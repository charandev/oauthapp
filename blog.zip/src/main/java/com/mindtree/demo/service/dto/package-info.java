/**
 * Data Transfer Objects.
 */
package com.mindtree.demo.service.dto;
