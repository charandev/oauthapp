(function() {
    'use strict';

    angular
        .module('demoApp')
        .config(stateConfig);

    stateConfig.$inject = ['$stateProvider'];

    function stateConfig($stateProvider) {
        $stateProvider
        .state('remo', {
            parent: 'entity',
            url: '/remo',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Remos'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/remo/remos.html',
                    controller: 'RemoController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
            }
        })
        .state('remo-detail', {
            parent: 'entity',
            url: '/remo/{id}',
            data: {
                authorities: ['ROLE_USER'],
                pageTitle: 'Remo'
            },
            views: {
                'content@': {
                    templateUrl: 'app/entities/remo/remo-detail.html',
                    controller: 'RemoDetailController',
                    controllerAs: 'vm'
                }
            },
            resolve: {
                entity: ['$stateParams', 'Remo', function($stateParams, Remo) {
                    return Remo.get({id : $stateParams.id}).$promise;
                }],
                previousState: ["$state", function ($state) {
                    var currentStateData = {
                        name: $state.current.name || 'remo',
                        params: $state.params,
                        url: $state.href($state.current.name, $state.params)
                    };
                    return currentStateData;
                }]
            }
        })
        .state('remo-detail.edit', {
            parent: 'remo-detail',
            url: '/detail/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/remo/remo-dialog.html',
                    controller: 'RemoDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Remo', function(Remo) {
                            return Remo.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('^', {}, { reload: false });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('remo.new', {
            parent: 'remo',
            url: '/new',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/remo/remo-dialog.html',
                    controller: 'RemoDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: function () {
                            return {
                                name: null,
                                id: null
                            };
                        }
                    }
                }).result.then(function() {
                    $state.go('remo', null, { reload: 'remo' });
                }, function() {
                    $state.go('remo');
                });
            }]
        })
        .state('remo.edit', {
            parent: 'remo',
            url: '/{id}/edit',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/remo/remo-dialog.html',
                    controller: 'RemoDialogController',
                    controllerAs: 'vm',
                    backdrop: 'static',
                    size: 'lg',
                    resolve: {
                        entity: ['Remo', function(Remo) {
                            return Remo.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('remo', null, { reload: 'remo' });
                }, function() {
                    $state.go('^');
                });
            }]
        })
        .state('remo.delete', {
            parent: 'remo',
            url: '/{id}/delete',
            data: {
                authorities: ['ROLE_USER']
            },
            onEnter: ['$stateParams', '$state', '$uibModal', function($stateParams, $state, $uibModal) {
                $uibModal.open({
                    templateUrl: 'app/entities/remo/remo-delete-dialog.html',
                    controller: 'RemoDeleteController',
                    controllerAs: 'vm',
                    size: 'md',
                    resolve: {
                        entity: ['Remo', function(Remo) {
                            return Remo.get({id : $stateParams.id}).$promise;
                        }]
                    }
                }).result.then(function() {
                    $state.go('remo', null, { reload: 'remo' });
                }, function() {
                    $state.go('^');
                });
            }]
        });
    }

})();
