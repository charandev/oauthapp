package com.mindtree.demo.service;

import com.mindtree.demo.service.dto.HotelDTO;
import java.util.List;

/**
 * Service Interface for managing Hotel.
 */
public interface HotelService {

    /**
     * Save a hotel.
     *
     * @param hotelDTO the entity to save
     * @return the persisted entity
     */
    HotelDTO save(HotelDTO hotelDTO);

    /**
     *  Get all the hotels.
     *  
     *  @return the list of entities
     */
    List<HotelDTO> findAll();

    /**
     *  Get the "id" hotel.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    HotelDTO findOne(Long id);

    /**
     *  Delete the "id" hotel.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);
}
