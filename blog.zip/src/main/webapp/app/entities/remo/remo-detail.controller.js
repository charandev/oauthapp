(function() {
    'use strict';

    angular
        .module('demoApp')
        .controller('RemoDetailController', RemoDetailController);

    RemoDetailController.$inject = ['$scope', '$rootScope', '$stateParams', 'previousState', 'entity', 'Remo'];

    function RemoDetailController($scope, $rootScope, $stateParams, previousState, entity, Remo) {
        var vm = this;

        vm.remo = entity;
        vm.previousState = previousState.name;

        var unsubscribe = $rootScope.$on('demoApp:remoUpdate', function(event, result) {
            vm.remo = result;
        });
        $scope.$on('$destroy', unsubscribe);
    }
})();
