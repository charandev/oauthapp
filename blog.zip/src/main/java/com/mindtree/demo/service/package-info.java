/**
 * Service layer beans.
 */
package com.mindtree.demo.service;
