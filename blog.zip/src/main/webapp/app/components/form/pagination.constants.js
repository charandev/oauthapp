(function() {
    'use strict';

    angular
        .module('demoApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
