package com.mindtree.demo.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.mindtree.demo.service.HotelService;
import com.mindtree.demo.web.rest.util.HeaderUtil;
import com.mindtree.demo.service.dto.HotelDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * REST controller for managing Hotel.
 */
@RestController
@RequestMapping("/api")
public class HotelResource {

    private final Logger log = LoggerFactory.getLogger(HotelResource.class);
        
    @Inject
    private HotelService hotelService;

    /**
     * POST  /hotels : Create a new hotel.
     *
     * @param hotelDTO the hotelDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new hotelDTO, or with status 400 (Bad Request) if the hotel has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/hotels")
    @Timed
    public ResponseEntity<HotelDTO> createHotel(@Valid @RequestBody HotelDTO hotelDTO) throws URISyntaxException {
        log.debug("REST request to save Hotel : {}", hotelDTO);
        if (hotelDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("hotel", "idexists", "A new hotel cannot already have an ID")).body(null);
        }
        HotelDTO result = hotelService.save(hotelDTO);
        return ResponseEntity.created(new URI("/api/hotels/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("hotel", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /hotels : Updates an existing hotel.
     *
     * @param hotelDTO the hotelDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated hotelDTO,
     * or with status 400 (Bad Request) if the hotelDTO is not valid,
     * or with status 500 (Internal Server Error) if the hotelDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/hotels")
    @Timed
    public ResponseEntity<HotelDTO> updateHotel(@Valid @RequestBody HotelDTO hotelDTO) throws URISyntaxException {
        log.debug("REST request to update Hotel : {}", hotelDTO);
        if (hotelDTO.getId() == null) {
            return createHotel(hotelDTO);
        }
        HotelDTO result = hotelService.save(hotelDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("hotel", hotelDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /hotels : get all the hotels.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of hotels in body
     */
    @GetMapping("/hotels")
    @Timed
    public List<HotelDTO> getAllHotels() {
        log.debug("REST request to get all Hotels");
        return hotelService.findAll();
    }

    /**
     * GET  /hotels/:id : get the "id" hotel.
     *
     * @param id the id of the hotelDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the hotelDTO, or with status 404 (Not Found)
     */
    @GetMapping("/hotels/{id}")
    @Timed
    public ResponseEntity<HotelDTO> getHotel(@PathVariable Long id) {
        log.debug("REST request to get Hotel : {}", id);
        HotelDTO hotelDTO = hotelService.findOne(id);
        return Optional.ofNullable(hotelDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /hotels/:id : delete the "id" hotel.
     *
     * @param id the id of the hotelDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/hotels/{id}")
    @Timed
    public ResponseEntity<Void> deleteHotel(@PathVariable Long id) {
        log.debug("REST request to delete Hotel : {}", id);
        hotelService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("hotel", id.toString())).build();
    }

}
