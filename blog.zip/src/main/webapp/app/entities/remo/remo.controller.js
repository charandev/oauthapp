(function() {
    'use strict';

    angular
        .module('demoApp')
        .controller('RemoController', RemoController);

    RemoController.$inject = ['$scope', '$state', 'Remo'];

    function RemoController ($scope, $state, Remo) {
        var vm = this;

        vm.remos = [];

        loadAll();

        function loadAll() {
            Remo.query(function(result) {
                vm.remos = result;
                vm.searchQuery = null;
            });
        }
    }
})();
