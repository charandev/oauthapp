/**
 * Spring Data JPA repositories.
 */
package com.mindtree.demo.repository;
