/**
 * Swagger api specific code.
 */
package com.mindtree.demo.config.apidoc;