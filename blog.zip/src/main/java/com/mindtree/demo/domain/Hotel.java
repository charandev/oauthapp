package com.mindtree.demo.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Hotel.
 */
@Entity
@Table(name = "hotel")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Hotel implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "no_of_items", nullable = false)
    private Integer noOfItems;

    @Column(name = "famous_item_of_the_day")
    private String famousItemOfTheDay;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Hotel name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getNoOfItems() {
        return noOfItems;
    }

    public Hotel noOfItems(Integer noOfItems) {
        this.noOfItems = noOfItems;
        return this;
    }

    public void setNoOfItems(Integer noOfItems) {
        this.noOfItems = noOfItems;
    }

    public String getFamousItemOfTheDay() {
        return famousItemOfTheDay;
    }

    public Hotel famousItemOfTheDay(String famousItemOfTheDay) {
        this.famousItemOfTheDay = famousItemOfTheDay;
        return this;
    }

    public void setFamousItemOfTheDay(String famousItemOfTheDay) {
        this.famousItemOfTheDay = famousItemOfTheDay;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Hotel hotel = (Hotel) o;
        if (hotel.id == null || id == null) {
            return false;
        }
        return Objects.equals(id, hotel.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Hotel{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", noOfItems='" + noOfItems + "'" +
            ", famousItemOfTheDay='" + famousItemOfTheDay + "'" +
            '}';
    }
}
