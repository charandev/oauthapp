(function() {
    'use strict';

    angular
        .module('demoApp')
        .controller('RemoDeleteController',RemoDeleteController);

    RemoDeleteController.$inject = ['$uibModalInstance', 'entity', 'Remo'];

    function RemoDeleteController($uibModalInstance, entity, Remo) {
        var vm = this;

        vm.remo = entity;
        vm.clear = clear;
        vm.confirmDelete = confirmDelete;

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function confirmDelete (id) {
            Remo.delete({id: id},
                function () {
                    $uibModalInstance.close(true);
                });
        }
    }
})();
