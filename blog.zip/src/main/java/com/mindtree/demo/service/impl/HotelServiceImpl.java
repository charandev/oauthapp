package com.mindtree.demo.service.impl;

import com.mindtree.demo.service.HotelService;
import com.mindtree.demo.domain.Hotel;
import com.mindtree.demo.repository.HotelRepository;
import com.mindtree.demo.service.dto.HotelDTO;
import com.mindtree.demo.service.mapper.HotelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing Hotel.
 */
@Service
@Transactional
public class HotelServiceImpl implements HotelService{

    private final Logger log = LoggerFactory.getLogger(HotelServiceImpl.class);
    
    @Inject
    private HotelRepository hotelRepository;

    @Inject
    private HotelMapper hotelMapper;

    /**
     * Save a hotel.
     *
     * @param hotelDTO the entity to save
     * @return the persisted entity
     */
    public HotelDTO save(HotelDTO hotelDTO) {
        log.debug("Request to save Hotel : {}", hotelDTO);
        Hotel hotel = hotelMapper.hotelDTOToHotel(hotelDTO);
        hotel = hotelRepository.save(hotel);
        HotelDTO result = hotelMapper.hotelToHotelDTO(hotel);
        return result;
    }

    /**
     *  Get all the hotels.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<HotelDTO> findAll() {
        log.debug("Request to get all Hotels");
        List<HotelDTO> result = hotelRepository.findAll().stream()
            .map(hotelMapper::hotelToHotelDTO)
            .collect(Collectors.toCollection(LinkedList::new));

        return result;
    }

    /**
     *  Get one hotel by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public HotelDTO findOne(Long id) {
        log.debug("Request to get Hotel : {}", id);
        Hotel hotel = hotelRepository.findOne(id);
        HotelDTO hotelDTO = hotelMapper.hotelToHotelDTO(hotel);
        return hotelDTO;
    }

    /**
     *  Delete the  hotel by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Hotel : {}", id);
        hotelRepository.delete(id);
    }
}
