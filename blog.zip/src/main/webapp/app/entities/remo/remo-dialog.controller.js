(function() {
    'use strict';

    angular
        .module('demoApp')
        .controller('RemoDialogController', RemoDialogController);

    RemoDialogController.$inject = ['$timeout', '$scope', '$stateParams', '$uibModalInstance', 'entity', 'Remo'];

    function RemoDialogController ($timeout, $scope, $stateParams, $uibModalInstance, entity, Remo) {
        var vm = this;

        vm.remo = entity;
        vm.clear = clear;
        vm.save = save;

        $timeout(function (){
            angular.element('.form-group:eq(1)>input').focus();
        });

        function clear () {
            $uibModalInstance.dismiss('cancel');
        }

        function save () {
            vm.isSaving = true;
            if (vm.remo.id !== null) {
                Remo.update(vm.remo, onSaveSuccess, onSaveError);
            } else {
                Remo.save(vm.remo, onSaveSuccess, onSaveError);
            }
        }

        function onSaveSuccess (result) {
            $scope.$emit('demoApp:remoUpdate', result);
            $uibModalInstance.close(result);
            vm.isSaving = false;
        }

        function onSaveError () {
            vm.isSaving = false;
        }


    }
})();
