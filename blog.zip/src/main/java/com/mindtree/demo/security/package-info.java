/**
 * Spring Security configuration.
 */
package com.mindtree.demo.security;
