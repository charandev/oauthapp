package com.mindtree.demo.web.rest;

import com.mindtree.demo.DemoApp;

import com.mindtree.demo.domain.Remo;
import com.mindtree.demo.repository.RemoRepository;
import com.mindtree.demo.service.RemoService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the RemoResource REST controller.
 *
 * @see RemoResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = DemoApp.class)
public class RemoResourceIntTest {

    private static final String DEFAULT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_NAME = "BBBBBBBBBB";

    @Inject
    private RemoRepository remoRepository;

    @Inject
    private RemoService remoService;

    @Inject
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Inject
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Inject
    private EntityManager em;

    private MockMvc restRemoMockMvc;

    private Remo remo;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        RemoResource remoResource = new RemoResource();
        ReflectionTestUtils.setField(remoResource, "remoService", remoService);
        this.restRemoMockMvc = MockMvcBuilders.standaloneSetup(remoResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setMessageConverters(jacksonMessageConverter).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Remo createEntity(EntityManager em) {
        Remo remo = new Remo()
                .name(DEFAULT_NAME);
        return remo;
    }

    @Before
    public void initTest() {
        remo = createEntity(em);
    }

    @Test
    @Transactional
    public void createRemo() throws Exception {
        int databaseSizeBeforeCreate = remoRepository.findAll().size();

        // Create the Remo

        restRemoMockMvc.perform(post("/api/remos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(remo)))
            .andExpect(status().isCreated());

        // Validate the Remo in the database
        List<Remo> remoList = remoRepository.findAll();
        assertThat(remoList).hasSize(databaseSizeBeforeCreate + 1);
        Remo testRemo = remoList.get(remoList.size() - 1);
        assertThat(testRemo.getName()).isEqualTo(DEFAULT_NAME);
    }

    @Test
    @Transactional
    public void createRemoWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = remoRepository.findAll().size();

        // Create the Remo with an existing ID
        Remo existingRemo = new Remo();
        existingRemo.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restRemoMockMvc.perform(post("/api/remos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(existingRemo)))
            .andExpect(status().isBadRequest());

        // Validate the Alice in the database
        List<Remo> remoList = remoRepository.findAll();
        assertThat(remoList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    public void getAllRemos() throws Exception {
        // Initialize the database
        remoRepository.saveAndFlush(remo);

        // Get all the remoList
        restRemoMockMvc.perform(get("/api/remos?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(remo.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())));
    }

    @Test
    @Transactional
    public void getRemo() throws Exception {
        // Initialize the database
        remoRepository.saveAndFlush(remo);

        // Get the remo
        restRemoMockMvc.perform(get("/api/remos/{id}", remo.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(remo.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingRemo() throws Exception {
        // Get the remo
        restRemoMockMvc.perform(get("/api/remos/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateRemo() throws Exception {
        // Initialize the database
        remoService.save(remo);

        int databaseSizeBeforeUpdate = remoRepository.findAll().size();

        // Update the remo
        Remo updatedRemo = remoRepository.findOne(remo.getId());
        updatedRemo
                .name(UPDATED_NAME);

        restRemoMockMvc.perform(put("/api/remos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedRemo)))
            .andExpect(status().isOk());

        // Validate the Remo in the database
        List<Remo> remoList = remoRepository.findAll();
        assertThat(remoList).hasSize(databaseSizeBeforeUpdate);
        Remo testRemo = remoList.get(remoList.size() - 1);
        assertThat(testRemo.getName()).isEqualTo(UPDATED_NAME);
    }

    @Test
    @Transactional
    public void updateNonExistingRemo() throws Exception {
        int databaseSizeBeforeUpdate = remoRepository.findAll().size();

        // Create the Remo

        // If the entity doesn't have an ID, it will be created instead of just being updated
        restRemoMockMvc.perform(put("/api/remos")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(remo)))
            .andExpect(status().isCreated());

        // Validate the Remo in the database
        List<Remo> remoList = remoRepository.findAll();
        assertThat(remoList).hasSize(databaseSizeBeforeUpdate + 1);
    }

    @Test
    @Transactional
    public void deleteRemo() throws Exception {
        // Initialize the database
        remoService.save(remo);

        int databaseSizeBeforeDelete = remoRepository.findAll().size();

        // Get the remo
        restRemoMockMvc.perform(delete("/api/remos/{id}", remo.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Remo> remoList = remoRepository.findAll();
        assertThat(remoList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
