package com.mindtree.demo.service.impl;

import com.mindtree.demo.service.RemoService;
import com.mindtree.demo.domain.Remo;
import com.mindtree.demo.repository.RemoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

/**
 * Service Implementation for managing Remo.
 */
@Service
@Transactional
public class RemoServiceImpl implements RemoService{

    private final Logger log = LoggerFactory.getLogger(RemoServiceImpl.class);
    
    @Inject
    private RemoRepository remoRepository;

    /**
     * Save a remo.
     *
     * @param remo the entity to save
     * @return the persisted entity
     */
    public Remo save(Remo remo) {
        log.debug("Request to save Remo : {}", remo);
        Remo result = remoRepository.save(remo);
        return result;
    }

    /**
     *  Get all the remos.
     *  
     *  @return the list of entities
     */
    @Transactional(readOnly = true) 
    public List<Remo> findAll() {
        log.debug("Request to get all Remos");
        List<Remo> result = remoRepository.findAll();

        return result;
    }

    /**
     *  Get one remo by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    @Transactional(readOnly = true) 
    public Remo findOne(Long id) {
        log.debug("Request to get Remo : {}", id);
        Remo remo = remoRepository.findOne(id);
        return remo;
    }

    /**
     *  Delete the  remo by id.
     *
     *  @param id the id of the entity
     */
    public void delete(Long id) {
        log.debug("Request to delete Remo : {}", id);
        remoRepository.delete(id);
    }
}
