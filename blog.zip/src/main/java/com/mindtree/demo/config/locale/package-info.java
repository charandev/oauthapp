/**
 * Locale specific code.
 */
package com.mindtree.demo.config.locale;
