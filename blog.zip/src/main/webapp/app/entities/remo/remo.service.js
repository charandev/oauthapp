(function() {
    'use strict';
    angular
        .module('demoApp')
        .factory('Remo', Remo);

    Remo.$inject = ['$resource'];

    function Remo ($resource) {
        var resourceUrl =  'api/remos/:id';

        return $resource(resourceUrl, {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    if (data) {
                        data = angular.fromJson(data);
                    }
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    }
})();
