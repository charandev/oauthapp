package com.mindtree.demo.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.mindtree.demo.domain.Remo;
import com.mindtree.demo.service.RemoService;
import com.mindtree.demo.web.rest.util.HeaderUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Remo.
 */
@RestController
@RequestMapping("/api")
public class RemoResource {

    private final Logger log = LoggerFactory.getLogger(RemoResource.class);
        
    @Inject
    private RemoService remoService;

    /**
     * POST  /remos : Create a new remo.
     *
     * @param remo the remo to create
     * @return the ResponseEntity with status 201 (Created) and with body the new remo, or with status 400 (Bad Request) if the remo has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/remos")
    @Timed
    public ResponseEntity<Remo> createRemo(@RequestBody Remo remo) throws URISyntaxException {
        log.debug("REST request to save Remo : {}", remo);
        if (remo.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("remo", "idexists", "A new remo cannot already have an ID")).body(null);
        }
        Remo result = remoService.save(remo);
        return ResponseEntity.created(new URI("/api/remos/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("remo", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /remos : Updates an existing remo.
     *
     * @param remo the remo to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated remo,
     * or with status 400 (Bad Request) if the remo is not valid,
     * or with status 500 (Internal Server Error) if the remo couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/remos")
    @Timed
    public ResponseEntity<Remo> updateRemo(@RequestBody Remo remo) throws URISyntaxException {
        log.debug("REST request to update Remo : {}", remo);
        if (remo.getId() == null) {
            return createRemo(remo);
        }
        Remo result = remoService.save(remo);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("remo", remo.getId().toString()))
            .body(result);
    }

    /**
     * GET  /remos : get all the remos.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of remos in body
     */
    @GetMapping("/remos")
    @Timed
    public List<Remo> getAllRemos() {
        log.debug("REST request to get all Remos");
        return remoService.findAll();
    }

    /**
     * GET  /remos/:id : get the "id" remo.
     *
     * @param id the id of the remo to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the remo, or with status 404 (Not Found)
     */
    @GetMapping("/remos/{id}")
    @Timed
    public ResponseEntity<Remo> getRemo(@PathVariable Long id) {
        log.debug("REST request to get Remo : {}", id);
        Remo remo = remoService.findOne(id);
        return Optional.ofNullable(remo)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * DELETE  /remos/:id : delete the "id" remo.
     *
     * @param id the id of the remo to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/remos/{id}")
    @Timed
    public ResponseEntity<Void> deleteRemo(@PathVariable Long id) {
        log.debug("REST request to delete Remo : {}", id);
        remoService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("remo", id.toString())).build();
    }

}
