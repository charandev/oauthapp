package com.mindtree.demo.service;

import com.mindtree.demo.domain.Remo;
import java.util.List;

/**
 * Service Interface for managing Remo.
 */
public interface RemoService {

    /**
     * Save a remo.
     *
     * @param remo the entity to save
     * @return the persisted entity
     */
    Remo save(Remo remo);

    /**
     *  Get all the remos.
     *  
     *  @return the list of entities
     */
    List<Remo> findAll();

    /**
     *  Get the "id" remo.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    Remo findOne(Long id);

    /**
     *  Delete the "id" remo.
     *
     *  @param id the id of the entity
     */
    void delete(Long id);
}
