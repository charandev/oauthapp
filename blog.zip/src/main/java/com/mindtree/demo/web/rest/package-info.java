/**
 * Spring MVC REST controllers.
 */
package com.mindtree.demo.web.rest;
