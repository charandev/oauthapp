package com.mindtree.demo.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;


/**
 * A DTO for the Hotel entity.
 */
public class HotelDTO implements Serializable {

    private Long id;

    @NotNull
    private String name;

    @NotNull
    private Integer noOfItems;

    private String famousItemOfTheDay;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public Integer getNoOfItems() {
        return noOfItems;
    }

    public void setNoOfItems(Integer noOfItems) {
        this.noOfItems = noOfItems;
    }
    public String getFamousItemOfTheDay() {
        return famousItemOfTheDay;
    }

    public void setFamousItemOfTheDay(String famousItemOfTheDay) {
        this.famousItemOfTheDay = famousItemOfTheDay;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        HotelDTO hotelDTO = (HotelDTO) o;

        if ( ! Objects.equals(id, hotelDTO.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "HotelDTO{" +
            "id=" + id +
            ", name='" + name + "'" +
            ", noOfItems='" + noOfItems + "'" +
            ", famousItemOfTheDay='" + famousItemOfTheDay + "'" +
            '}';
    }
}
