package com.mindtree.demo.repository;

import com.mindtree.demo.domain.Remo;

import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Remo entity.
 */
@SuppressWarnings("unused")
public interface RemoRepository extends JpaRepository<Remo,Long> {

}
